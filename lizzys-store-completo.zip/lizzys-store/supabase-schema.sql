-- Ejecuta esto en Supabase: panel izquierdo > SQL Editor > New query > pega y dale RUN

create table products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text,
  price numeric not null,
  category text not null check (category in ('maquillaje','facial','capilar','electrodomesticos','variedad')),
  stock_status text not null default 'disponible' check (stock_status in ('disponible','pedido','agotado')),
  emoji text default '🛍',
  created_at timestamp with time zone default now()
);

-- Permite que cualquiera pueda LEER los productos (necesario para que la tienda los muestre)
alter table products enable row level security;
create policy "Lectura pública de productos"
  on products for select
  using (true);

-- Ejemplo de productos para empezar (puedes editarlos/borrarlos desde Table Editor)
insert into products (name, description, price, category, stock_status, emoji) values
('Paleta de sombras Rosé', '12 tonos mate y shimmer', 450, 'maquillaje', 'disponible', '💄'),
('Serum de vitamina C', 'Facial, 30ml', 320, 'facial', 'disponible', '🧴'),
('Plancha para cabello', 'Cerámica, temperatura ajustable', 890, 'capilar', 'pedido', '💇'),
('Licuadora compacta', '600W, 3 velocidades', 1250, 'electrodomesticos', 'disponible', '🔌');
