# Guía para publicar Lizzy's Store (gratis, sin dominio propio)

Vas a usar 3 servicios gratuitos:
- **Supabase** → tu base de datos (donde guardas los productos y el stock)
- **Stripe** → los pagos con tarjeta
- **Netlify** → donde vive tu página web (te da una dirección gratis tipo `lizzysstore.netlify.app`)

No necesitas instalar nada en tu computadora. Todo se hace desde el navegador.

---

## Paso 1 — Crear la base de datos (Supabase)

1. Entra a **supabase.com** → crea una cuenta gratis → "New Project".
2. Ponle un nombre (ej. "lizzys-store") y una contraseña (guárdala).
3. Cuando el proyecto esté listo, ve al menú izquierdo → **SQL Editor** → **New query**.
4. Abre el archivo `supabase-schema.sql` (incluido aquí), copia todo su contenido, pégalo y presiona **RUN**. Esto crea tu tabla de productos con 4 productos de ejemplo.
5. Ve a **Project Settings** (ícono de engranaje) → **API**. Copia dos datos:
   - **Project URL**
   - **anon public key**
6. Abre el archivo `config.js` y reemplaza:
   ```js
   const SUPABASE_URL = "TU_PROJECT_URL";
   const SUPABASE_ANON_KEY = "TU_ANON_KEY";
   ```

**Para controlar el stock:** entra a Supabase → **Table Editor** → tabla `products`. Ahí puedes agregar productos nuevos, cambiar el precio, subir foto (usa un enlace de imagen) o cambiar `stock_status` a:
- `disponible`
- `pedido` (se muestra como "Reponible en 1 semana")
- `agotado`

No necesitas tocar código para actualizar tu inventario, solo editas esa tabla como si fuera Excel.

---

## Paso 2 — Crear la cuenta de pagos (Stripe)

1. Entra a **stripe.com** → crea una cuenta gratis (activa el modo "Test" primero para probar sin dinero real).
2. Ve a **Developers → API keys**.
3. Copia la **Secret key** (empieza con `sk_...`). La usarás en el Paso 4 — nunca la pegues en `config.js` ni en ningún archivo del sitio.
4. Cuando quieras cobrar de verdad, completa la activación de tu cuenta (datos bancarios) y cambia del modo Test al modo Live.

---

## Paso 3 — Subir el código a GitHub (sin usar comandos)

1. Entra a **github.com** → crea una cuenta gratis.
2. Clic en **New repository** → nómbralo `lizzys-store` → **Create repository**.
3. Clic en **"uploading an existing file"** → arrastra TODOS los archivos y carpetas de tu proyecto (`index.html`, `styles.css`, `app.js`, `config.js`, `exito.html`, `netlify.toml`, `package.json`, la carpeta `netlify/`) → **Commit changes**.

---

## Paso 4 — Publicar en Netlify

1. Entra a **netlify.com** → crea una cuenta gratis (puedes usar tu cuenta de GitHub para entrar).
2. Clic en **Add new site → Import an existing project → GitHub** → autoriza y selecciona el repositorio `lizzys-store`.
3. Deja la configuración por defecto y clic en **Deploy**.
4. En 1-2 minutos tu tienda estará publicada en una dirección como `https://lizzys-store-xxxx.netlify.app` (puedes cambiarle el nombre en **Site settings → Change site name**).
5. Ahora agrega tu clave de Stripe de forma segura: **Site settings → Environment variables → Add a variable**:
   - Nombre: `STRIPE_SECRET_KEY` → Valor: tu Secret key de Stripe (Paso 2).
6. Ve a **Deploys** → **Trigger deploy** para que se aplique.

¡Listo! Tu tienda ya está en línea, con carrito y pagos funcionando, sin haber comprado ningún dominio.

---

## ¿Y si más adelante quiero un dominio propio (ej. lizzysstore.com)?

Lo compras donde quieras (Namecheap, GoDaddy, etc.) y en Netlify vas a **Domain settings → Add a domain** — Netlify te guía para conectarlo. No es necesario para empezar a vender.

---

## Resumen de qué controla cada cosa

| Quiero... | Dónde lo hago |
|---|---|
| Agregar/quitar un producto | Supabase → Table Editor |
| Marcar algo como agotado o "reponible en 1 semana" | Supabase → Table Editor → columna `stock_status` |
| Ver mis ventas / pagos | Stripe → Payments |
| Cambiar el diseño o textos | Archivos `index.html` / `styles.css` (edítalos en GitHub y Netlify vuelve a publicar solo) |
